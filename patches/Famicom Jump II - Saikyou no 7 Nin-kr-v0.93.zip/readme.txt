﻿[1. 게임 제목]
Famicom Jump II - Saikyou no 7 Nin
한글 패치 v0.93

[2. 원본롬 이름]
Famicom Jump II - Saikyou no 7 Nin (Japan).nes

[3. 해시값]
원본 파일
Famicom Jump II - Saikyou no 7 Nin (Japan).nes
크기: 524,304 바이트
SHA-256: e8914e73c2c2e6ddc2bd4021eaf215e446fba70e5561021cb83250adcfa949fe

패치 적용 결과
famicom-jump-ii-ko-v0.93.nes
크기: 1,048,592 바이트
SHA-256: 3dbcb7c2ac9669796b96be9bbad9ae52b7d28779b894bd3f27e8619e6c896578

패치 파일
Famicom Jump II - Saikyou no 7 Nin-kr-v0.93.xdelta
SHA-256: 65ace6a2c374e2cff2b92378672eef33e32e6f6b928bc5235e6e699720123799

해시 확인 (PowerShell):
Get-FileHash -Algorithm SHA256 -LiteralPath "파일 경로"
MD5 또는 SHA-1로 기록된 원본은 -Algorithm MD5 또는 -Algorithm SHA1로 확인하세요.
파일명보다 실제 크기와 해시가 일치하는지 확인하세요.

[4. 설치 방법]
1) 원본 게임 파일과 게임 내 저장 파일을 먼저 백업합니다.
2) ZIP을 새 폴더에 풉니다. xdelta3 호환 패처와 위에 기록된 미수정 원본을 별도로 준비합니다.
3) 패처에서 아래 원본과 대응하는 xdelta를 선택하고, 원본과 다른 경로에 새 출력 파일을 만듭니다.
   이전 한글판에 덧씌우지 마세요. 체크섬 오류를 무시하거나 강제로 적용하지 마세요.

원본 → 패치 → 출력 파일
Famicom Jump II - Saikyou no 7 Nin (Japan).nes → Famicom Jump II - Saikyou no 7 Nin-kr-v0.93.xdelta → famicom-jump-ii-ko-v0.93.nes
xdelta3.exe -d -s "원본\Famicom Jump II - Saikyou no 7 Nin (Japan).nes" "Famicom Jump II - Saikyou no 7 Nin-kr-v0.93.xdelta" "한글판\famicom-jump-ii-ko-v0.93.nes"

명령줄을 쓰려면 먼저 패치 폴더 안에 원본 폴더와 한글판 폴더를 만들고,
원본 폴더에 입력 파일을 복사합니다. xdelta3.exe는 별도로 준비해 명령 실행 경로에서 사용할 수 있게 두세요.
GUI 패처를 사용해도 위 대응 관계와 출력 파일명을 동일하게 지정하면 됩니다.
4) 기록된 결과 해시가 있으면 적용 후 파일과 대조합니다. 게임/에뮬레이터를 완전히 종료한 뒤 새 결과를 실행합니다.
   이전 버전의 상태 저장 대신 게임 내 저장을 사용하고, 기존 저장은 백업본으로 보관하세요.

[5. 버전 변경사항]
v0.93: v0.92의 모든 내용을 포함하며, 전투 중 START 정보창의 레벨·공격력·방어력·이동력 아이콘이 깨지고 캐릭터 이름까지 훼손되던 문제를 수정했습니다.
지원 대상은 Mesen 독립판과 RetroArch Mesen 코어입니다. 실기와 Nestopia는 지원하지 않습니다.
이번 START 창 수정은 Mesen CE 2.2.1에서 같은 저장 데이터와 입력으로 수정 전후를 확인했습니다. 창 두 차례 열기, 숫자·하트, 창 닫기 후 전투 복귀를 확인한 범위이며 모바일 에뮬레이터 및 게임 전체 재플레이 검증은 아닙니다.
영어 스태프롤과 원본의 상하단 스크롤 타일 현상은 유지합니다.
미확인 분기에서 오역·미번역·표시 문제가 남아 있을 수 있습니다. 게임 내 세이브 형식은 같으며 기존 저장을 백업하고 새 ROM으로 완전히 재시작해 게임 내 이어하기를 사용하세요. 이전 상태 저장은 사용하지 마세요.
ROM 이름을 바꾸면 기존 .sav/.srm 복사본의 기본 파일명도 새 ROM에 맞추세요.

2026-11-08 배포 형식 통일:
- 배포 ZIP에는 xdelta와 readme.txt만 포함합니다. 다중 디스크·파일은 필요한 xdelta를 모두 포함합니다.
- 기존 한글화 내용과 패치 버전은 유지했습니다. 이번 작업은 배포 구성과 안내문을 정리한 것입니다.

게임 및 원본 자산의 권리는 각 권리자에게 있습니다. 비공식 팬 번역입니다.
원본 ROM·디스크 이미지·완성 게임 파일·BIOS·에뮬레이터는 포함하지 않습니다.

글꼴·저작권 고지 (별도 파일 대신 이 안내문에 수록)
아래의 기존 고지 파일명은 이 안내문 안의 각 고지 제목입니다. 해당 이름의 별도 파일은 필요하지 않습니다.
Denkichip-OFL.txt
Copyright (c) 2026 Lee Minseo (quiple@quiple.dev).
Copyright (c) 2026 The x8y12pxDenkiChip Project Authors (https://github.com/hicchicc/x8y12pxDenkiChip).

This Font Software is licensed under the SIL Open Font License, Version 1.1.
This license is copied below, and is also available with a FAQ at:
https://openfontlicense.org


-----------------------------------------------------------
SIL OPEN FONT LICENSE Version 1.1 - 26 February 2007
-----------------------------------------------------------

PREAMBLE
The goals of the Open Font License (OFL) are to stimulate worldwide
development of collaborative font projects, to support the font creation
efforts of academic and linguistic communities, and to provide a free and
open framework in which fonts may be shared and improved in partnership
with others.

The OFL allows the licensed fonts to be used, studied, modified and
redistributed freely as long as they are not sold by themselves. The
fonts, including any derivative works, can be bundled, embedded,
redistributed and/or sold with any software provided that any reserved
names are not used by derivative works. The fonts and derivatives,
however, cannot be released under any other type of license. The
requirement for fonts to remain under this license does not apply
to any document created using the fonts or their derivatives.

DEFINITIONS
"Font Software" refers to the set of files released by the Copyright
Holder(s) under this license and clearly marked as such. This may
include source files, build scripts and documentation.

"Reserved Font Name" refers to any names specified as such after the
copyright statement(s).

"Original Version" refers to the collection of Font Software components as
distributed by the Copyright Holder(s).

"Modified Version" refers to any derivative made by adding to, deleting,
or substituting -- in part or in whole -- any of the components of the
Original Version, by changing formats or by porting the Font Software to a
new environment.

"Author" refers to any designer, engineer, programmer, technical
writer or other person who contributed to the Font Software.

PERMISSION & CONDITIONS
Permission is hereby granted, free of charge, to any person obtaining
a copy of the Font Software, to use, study, copy, merge, embed, modify,
redistribute, and sell modified and unmodified copies of the Font
Software, subject to the following conditions:

1) Neither the Font Software nor any of its individual components,
in Original or Modified Versions, may be sold by itself.

2) Original or Modified Versions of the Font Software may be bundled,
redistributed and/or sold with any software, provided that each copy
contains the above copyright notice and this license. These can be
included either as stand-alone text files, human-readable headers or
in the appropriate machine-readable metadata fields within text or
binary files as long as those fields can be easily viewed by the user.

3) No Modified Version of the Font Software may use the Reserved Font
Name(s) unless explicit written permission is granted by the corresponding
Copyright Holder. This restriction only applies to the primary font name as
presented to the users.

4) The name(s) of the Copyright Holder(s) or the Author(s) of the Font
Software shall not be used to promote, endorse or advertise any
Modified Version, except to acknowledge the contribution(s) of the
Copyright Holder(s) and the Author(s) or with their explicit written
permission.

5) The Font Software, modified or unmodified, in part or in whole,
must be distributed entirely under this license, and must not be
distributed under any other license. The requirement for fonts to
remain under this license does not apply to any document created
using the Font Software.

TERMINATION
This license becomes null and void if any of the above conditions are
not met.

DISCLAIMER
THE FONT SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT
OF COPYRIGHT, PATENT, TRADEMARK, OR OTHER RIGHT. IN NO EVENT SHALL THE
COPYRIGHT HOLDER BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
INCLUDING ANY GENERAL, SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL
DAMAGES, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF THE USE OR INABILITY TO USE THE FONT SOFTWARE OR FROM
OTHER DEALINGS IN THE FONT SOFTWARE.

Galmuri-OFL.txt
Copyright (c) 2019–2025 Lee Minseo (quiple@quiple.dev)

This font software is licensed under the SIL Open Font License, Version 1.1.
This license is copied below, and is also available with a FAQ at:
https://openfontlicense.org


-----------------------------------------------------------
SIL OPEN FONT LICENSE Version 1.1 - 26 February 2007
-----------------------------------------------------------

PREAMBLE
The goals of the Open Font License (OFL) are to stimulate worldwide
development of collaborative font projects, to support the font creation
efforts of academic and linguistic communities, and to provide a free and
open framework in which fonts may be shared and improved in partnership
with others.

The OFL allows the licensed fonts to be used, studied, modified and
redistributed freely as long as they are not sold by themselves. The
fonts, including any derivative works, can be bundled, embedded,
redistributed and/or sold with any software provided that any reserved
names are not used by derivative works. The fonts and derivatives,
however, cannot be released under any other type of license. The
requirement for fonts to remain under this license does not apply
to any document created using the fonts or their derivatives.

DEFINITIONS
"Font Software" refers to the set of files released by the Copyright
Holder(s) under this license and clearly marked as such. This may
include source files, build scripts and documentation.

"Reserved Font Name" refers to any names specified as such after the
copyright statement(s).

"Original Version" refers to the collection of Font Software components as
distributed by the Copyright Holder(s).

"Modified Version" refers to any derivative made by adding to, deleting,
or substituting -- in part or in whole -- any of the components of the
Original Version, by changing formats or by porting the Font Software to a
new environment.

"Author" refers to any designer, engineer, programmer, technical
writer or other person who contributed to the Font Software.

PERMISSION & CONDITIONS
Permission is hereby granted, free of charge, to any person obtaining
a copy of the Font Software, to use, study, copy, merge, embed, modify,
redistribute, and sell modified and unmodified copies of the Font
Software, subject to the following conditions:

1) Neither the Font Software nor any of its individual components,
in Original or Modified Versions, may be sold by itself.

2) Original or Modified Versions of the Font Software may be bundled,
redistributed and/or sold with any software, provided that each copy
contains the above copyright notice and this license. These can be
included either as stand-alone text files, human-readable headers or
in the appropriate machine-readable metadata fields within text or
binary files as long as those fields can be easily viewed by the user.

3) No Modified Version of the Font Software may use the Reserved Font
Name(s) unless explicit written permission is granted by the corresponding
Copyright Holder. This restriction only applies to the primary font name as
presented to the users.

4) The name(s) of the Copyright Holder(s) or the Author(s) of the Font
Software shall not be used to promote, endorse or advertise any
Modified Version, except to acknowledge the contribution(s) of the
Copyright Holder(s) and the Author(s) or with their explicit written
permission.

5) The Font Software, modified or unmodified, in part or in whole,
must be distributed entirely under this license, and must not be
distributed under any other license. The requirement for fonts to
remain under this license does not apply to any document created
using the Font Software.

TERMINATION
This license becomes null and void if any of the above conditions are
not met.

DISCLAIMER
THE FONT SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT
OF COPYRIGHT, PATENT, TRADEMARK, OR OTHER RIGHT. IN NO EVENT SHALL THE
COPYRIGHT HOLDER BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
INCLUDING ANY GENERAL, SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL
DAMAGES, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF THE USE OR INABILITY TO USE THE FONT SOFTWARE OR FROM
OTHER DEALINGS IN THE FONT SOFTWARE.
