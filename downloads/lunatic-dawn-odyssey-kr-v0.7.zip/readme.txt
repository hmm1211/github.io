﻿[게임 제목]
Lunatic Dawn - Odyssey (루나틱 던 오디세이)
PlayStation 일본판 한글 패치 v0.7

[원본롬 이름]
Lunatic Dawn - Odyssey (Japan) (Track 1).bin
Lunatic Dawn - Odyssey (Japan) (Track 2).bin
Lunatic Dawn - Odyssey (Japan).cue

Track 1은 패치를 적용할 데이터 트랙입니다. Track 2는 오디오 트랙이며, CUE는 두 트랙을 함께 실행할 때 사용합니다.

[해시값]
모두 SHA-256 기준입니다.

원본 Track 1 (364,087,248바이트)
ea2cee2d365bfb7513312350ea0e7a308243f802140bd5980267f67b58f6bcd5

원본 Track 2 (37,399,152바이트)
09d9237b71348e8bc480529bf9f798fa1a05361634f8df31ff5ef42a42f3405b

원본 CUE (230바이트, 참고용)
5c0e94e6a1f724832340fb25b3bcecf40a373cc019f800dd555dbf58d545ef1c

한글 패치 적용 후 Track 1 (364,087,248바이트)
7486411c16dd694f09da6e630df0d014f7d5ff3e6f8c294148e8085afd22acad

[설치 방법]
1. 일본판 원본 BIN 2개와 CUE가 있는 폴더에 이 ZIP을 풉니다. 이전 v0.7을 설치한 경우에도 일본판 원본 Track 1에서 시작합니다. xdelta3 공식 배포 페이지에서 Windows용 압축 파일을 받아 xdelta3.exe도 같은 폴더에 둡니다.
   https://github.com/jmacd/xdelta/releases/tag/v3.2.0

2. 원본 폴더에서 PowerShell을 열고 다음 명령으로 Track 1의 해시를 확인합니다. 위의 원본 Track 1 해시와 같으면 다음 단계로 진행합니다.
   Get-FileHash -Algorithm SHA256 -LiteralPath "Lunatic Dawn - Odyssey (Japan) (Track 1).bin"

3. 원본 폴더 안에 KR이라는 빈 폴더를 만듭니다. 기존 KR 폴더가 있으면 이름을 바꾸어 보관한 뒤 새 KR 폴더를 만듭니다. 원본 CUE와 Track 2를 KR 폴더에 같은 이름으로 복사합니다.

4. 2단계의 PowerShell에서 다음 명령을 한 줄로 실행합니다. KR 폴더에 한글판 Track 1이 생성됩니다.
   .\xdelta3.exe -d -s "Lunatic Dawn - Odyssey (Japan) (Track 1).bin" "lunatic-dawn-odyssey-kr-v0.7.xdelta" "KR\Lunatic Dawn - Odyssey (Japan) (Track 1).bin"

5. 다음 명령의 결과를 위의 '한글 패치 적용 후 Track 1' 해시와 대조합니다. 일치하면 PS1 에뮬레이터에서 아래 CUE를 엽니다.
   Get-FileHash -Algorithm SHA256 -LiteralPath "KR\Lunatic Dawn - Odyssey (Japan) (Track 1).bin"

   KR\Lunatic Dawn - Odyssey (Japan).cue

[버전 변경사항]
v0.7 (2026-11-27)

- 타이틀 화면의 영문 로고를 한글 로고 '루나틱 던 오디세이'로 교체했습니다.
- 튜토리얼, 이벤트와 일반 NPC 대사, 의뢰, 메뉴, 인명, 장비·아이템·몬스터 이름을 한글화했습니다.
- 이름 입력 화면에서 자음과 모음을 조합해 한글 이름을 최대 일곱 글자까지 입력할 수 있습니다. 기본 이름은 베리오스입니다.
- 대사의 줄바꿈과 작은따옴표 위치를 다듬고 공백, 마침표, 쉼표, 말줄임표(...)를 반각으로 통일했습니다.
- 노래 가사, 아이템·몬스터 도감, 옛 지도 지명과 능력치 화면의 일본어를 교체했습니다. 도감의 작은 지도 안에도 한글 지명을 넣었습니다.
- 게임 오버 2편과 엔딩 4편의 일본어 자막을 한글화했습니다. 영상의 영문 표기와 음성·음악은 원본을 유지합니다.
- 구버전 세이브를 불러오면 가나 이름과 저장 장소가 한글로 표시됩니다. 저장 목록에서 두 이름의 글자가 겹치던 문제도 수정했습니다.

한글 표시에 사용한 갈무리 글꼴의 저작권 표시와 이용 조건을 아래에 싣습니다.

Copyright © 2019–2025 Lee Minseo (quiple@quiple.dev)

This font software is licensed under the SIL Open Font License, Version 1.1.
This license is copied below, and is also available with a FAQ at:
https://openfontlicense.org

SIL OPEN FONT LICENSE Version 1.1 - 26 February 2007

PREAMBLE

The goals of the Open Font License (OFL) are to stimulate worldwide
development of collaborative font projects, to support the font creation
efforts of academic and linguistic communities, and to provide a free and
open framework in which fonts may be shared and improved in partnership
with others.

The OFL allows the licensed fonts to be used, studied, modified and
redistributed freely as long as they are not sold by themselves. The
fonts, including any derivative works, can be bundled, embedded,
redistributed and/or sold with any software provided that any reserved
names are not used by derivative works. The fonts and derivatives,
however, cannot be released under any other type of license. The
requirement for fonts to remain under this license does not apply
to any document created using the fonts or their derivatives.

DEFINITIONS

"Font Software" refers to the set of files released by the Copyright
Holder(s) under this license and clearly marked as such. This may
include source files, build scripts and documentation.

"Reserved Font Name" refers to any names specified as such after the
copyright statement(s).

"Original Version" refers to the collection of Font Software components as
distributed by the Copyright Holder(s).

"Modified Version" refers to any derivative made by adding to, deleting,
or substituting -- in part or in whole -- any of the components of the
Original Version, by changing formats or by porting the Font Software to a
new environment.

"Author" refers to any designer, engineer, programmer, technical
writer or other person who contributed to the Font Software.

PERMISSION & CONDITIONS

Permission is hereby granted, free of charge, to any person obtaining
a copy of the Font Software, to use, study, copy, merge, embed, modify,
redistribute, and sell modified and unmodified copies of the Font
Software, subject to the following conditions:

1. Neither the Font Software nor any of its individual components,
in Original or Modified Versions, may be sold by itself.

2. Original or Modified Versions of the Font Software may be bundled,
redistributed and/or sold with any software, provided that each copy
contains the above copyright notice and this license. These can be
included either as stand-alone text files, human-readable headers or
in the appropriate machine-readable metadata fields within text or
binary files as long as those fields can be easily viewed by the user.

3. No Modified Version of the Font Software may use the Reserved Font
Name(s) unless explicit written permission is granted by the corresponding
Copyright Holder. This restriction only applies to the primary font name as
presented to the users.

4. The name(s) of the Copyright Holder(s) or the Author(s) of the Font
Software shall not be used to promote, endorse or advertise any
Modified Version, except to acknowledge the contribution(s) of the
Copyright Holder(s) and the Author(s) or with their explicit written
permission.

5. The Font Software, modified or unmodified, in part or in whole,
must be distributed entirely under this license, and must not be
distributed under any other license. The requirement for fonts to
remain under this license does not apply to any document created
using the Font Software.

TERMINATION

This license becomes null and void if any of the above conditions are
not met.

DISCLAIMER

THE FONT SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT
OF COPYRIGHT, PATENT, TRADEMARK, OR OTHER RIGHT. IN NO EVENT SHALL THE
COPYRIGHT HOLDER BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
INCLUDING ANY GENERAL, SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL
DAMAGES, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF THE USE OR INABILITY TO USE THE FONT SOFTWARE OR FROM
OTHER DEALINGS IN THE FONT SOFTWARE.
