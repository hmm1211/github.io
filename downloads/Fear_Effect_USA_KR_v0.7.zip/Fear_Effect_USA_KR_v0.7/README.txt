﻿Fear Effect (USA) 한국어 패치 v0.7
배포 패키지 작성일: 2026-11-02

1. 대상 게임과 버전
게임: Fear Effect / 플랫폼: Sony PlayStation (PS1) / 지역: USA (북미판)
총 4장. 각 디스크는 단일 트랙 MODE2/2352, INDEX 01 00:00:00의 BIN/CUE 형식입니다.
아래 해시와 일치하는 수정하지 않은 원본 BIN에만 적용하세요.
해시는 CUE나 압축 파일이 아니라 BIN 파일 전체를 기준으로 계산했습니다.
파일명이 같아도 해시가 다르면 지원 원본으로 확인된 파일이 아닙니다.
다른 지역판, 기존 한글 패치본, CHD/PBP/ISO 파일에 직접 적용하지 마세요.

2. 원본 ROM 정보 및 해시

Disc 1 / SLUS-00920
파일명: Fear Effect (USA) (Disc 1).bin
크기: 487,435,536 bytes (487435536 bytes)
CRC32: 0044d5f7
MD5: e08b3a0d9694decd3ef9bc41c212bf1b
SHA1: e96eb6d83dd890103b3d3511cb84da73adab2cde
SHA256: 735d72318f5076957aa6c51b523dfa2a4b3002d162f1725036475895e6dcfc98

Disc 2 / SLUS-01056
파일명: Fear Effect (USA) (Disc 2).bin
크기: 505,757,616 bytes (505757616 bytes)
CRC32: cb8e774f
MD5: dff47ce1c1ec5a9c5a35820224486b22
SHA1: 0c2ffb3dd07ffb628b1fa69ca841cec141da11dd
SHA256: 178a0d89ab9530b176b6590dc6b0824fe8b230952648e875b564c6fafbd572cf

Disc 3 / SLUS-01057
파일명: Fear Effect (USA) (Disc 3).bin
크기: 451,666,320 bytes (451666320 bytes)
CRC32: fd0f561b
MD5: cd6fc71e6f452e1b4027250dd7d6d65c
SHA1: a4205816f6486d8d1f5b97195370fd402003f983
SHA256: c368bfee914453a19a6bf6df5ae0f376578a1b8d7687eb19a9e9948c48ad259d

Disc 4 / SLUS-01058
파일명: Fear Effect (USA) (Disc 4).bin
크기: 509,955,936 bytes (509955936 bytes)
CRC32: 9853995e
MD5: e269350708617a92359ceef2d7838f3c
SHA1: bc1762d51eb1e35b940ae304af6622e9d9eb989d
SHA256: 534254aca0e0c918a68f4496a80ef7f613b88384966baaf487bc2086e6be5f8c

3. 패치 적용 방법
ZIP을 폴더에 풀고 xdelta3 또는 xdeltaUI를 준비하세요. 패처 실행 파일은 포함하지 않았습니다.
원본 BIN 4개를 보관하고, 각 디스크에 같은 번호의 .xdelta를 개별 적용합니다.
xdeltaUI: Apply Patch에서 Patch = 해당 .xdelta, Source File = 해당 원본 .bin,
Output File = 아래 지정된 한글판 .bin 이름으로 선택합니다. CUE에는 패치를 적용하지 않습니다.
Windows PowerShell의 SHA-256 확인 예:
  Get-FileHash -Algorithm SHA256 -LiteralPath "Fear Effect (USA) (Disc 1).bin"

명령줄 적용 예 (원본 BIN, 패치, xdelta3.exe가 같은 폴더에 있을 때):
  .\xdelta3.exe -d -s "Fear Effect (USA) (Disc 1).bin" "Fear_Effect_USA_KR_v0.7_Disc1.xdelta" "Fear_Effect_USA_KR_v0.7_Disc1.bin"
  .\xdelta3.exe -d -s "Fear Effect (USA) (Disc 2).bin" "Fear_Effect_USA_KR_v0.7_Disc2.xdelta" "Fear_Effect_USA_KR_v0.7_Disc2.bin"
  .\xdelta3.exe -d -s "Fear Effect (USA) (Disc 3).bin" "Fear_Effect_USA_KR_v0.7_Disc3.xdelta" "Fear_Effect_USA_KR_v0.7_Disc3.bin"
  .\xdelta3.exe -d -s "Fear Effect (USA) (Disc 4).bin" "Fear_Effect_USA_KR_v0.7_Disc4.xdelta" "Fear_Effect_USA_KR_v0.7_Disc4.bin"

4개 출력 BIN과 동봉한 CUE 4개, M3U를 같은 폴더에 놓습니다.
Fear_Effect_USA_KR_v0.7.m3u를 에뮬레이터에서 열면 4장 목록을 함께 불러올 수 있습니다.
디스크별로 실행할 때는 해당 CUE를 여세요. 디스크 교체는 에뮬레이터의 디스크 교체 기능을 사용합니다.
출력 BIN 이름을 바꿨다면 CUE 내부 FILE 이름도 같게 수정해야 합니다.
기존 강제 저장 상태 대신 게임을 완전히 종료한 뒤 새로 부팅하세요.
기존 메모리카드 저장은 먼저 백업하는 것을 권장합니다.

4. 정상 적용 결과 (BIN SHA-256)
Fear_Effect_USA_KR_v0.7_Disc1.bin
  크기: 488341056 bytes
  SHA-256: 9302c65b00c33191eae9f529bed177f7b486a0fca9ee9af877e6f306ccdcf4df
Fear_Effect_USA_KR_v0.7_Disc2.bin
  크기: 506663136 bytes
  SHA-256: 42047ed107839b8e601d31318995286b1b161abdeabe5c966e9fb995a7069fb4
Fear_Effect_USA_KR_v0.7_Disc3.bin
  크기: 452571840 bytes
  SHA-256: 74cdfad81e1666c1098c49e364d3e8d8f720cec4e3d7aaae22a8065cd1149791
Fear_Effect_USA_KR_v0.7_Disc4.bin
  크기: 510861456 bytes
  SHA-256: 565aeb07ce2546beb9ebbe33b9ef54a7f2cde649ead6b236e4ba6e0313396163

5. v0.7 적용 내용
- 사용자 번역 자막 865개 고유 표시 항목을 4장에 적용. 원본 자막 타이밍 유지.
- 갈무리11 12px 자막 및 문자 UI. 두 줄 자막의 줄 간격 조정. 자막 기본값 ON.
- 한국어 타이틀 로고, 새 게임 / 불러오기 / 설정 및 설정 내부 메뉴 이미지 적용.
- 메인 메뉴 글자를 기존 설정 메뉴의 크기와 느낌에 맞춤. X 선택, 삼각형 뒤로 안내 유지.
- 24시간 전 안내, 전보 번역 자막, 전기 장치 패널, 단어 힌트표 적용.
- 동영상 및 음성은 재인코딩하지 않음. 보안 모니터·게임 오버·오프닝 영상 크레딧은 원본 유지.

6. 검증 범위 및 남은 확인 사항
v0.7은 전체 플레이 검수를 완료한 최종판이 아닙니다.
4장 새 부팅, 1장 메인 메뉴의 세 선택 상태, 설정·소리·조작·크레딧의 대표 경로를 확인했습니다.
배포 패치 4개를 원본에 다시 적용하여 결과 BIN 전체 해시가 검증된 빌드와 일치함을 확인했습니다.
디스크 전체 차이 및 수정 섹터 EDC/ECC 검사, 미수정 TIM/TM·영상·음성 보존 검사를 통과했습니다.
전체 게임 완주, 실제 진행 중 4장 교체, 후반 메모리 부하, 실기 구동, 퍼즐 실제 완수는 미검증입니다.
일부 동적 아이템 획득 안내 및 PAUSE/디스크 상태 문자 아틀라스는 영문이 남을 수 있습니다.
영상 오버레이의 개별 렌더링 검증은 전체 플레이 경로 검증을 뜻하지 않습니다.

7. 포함 파일
디스크별 xdelta 4개 / CUE 4개 / M3U / README.txt / manifest.json / SHA256SUMS.txt / 폰트 라이선스
원본 게임 이미지와 패치 적용된 게임 이미지는 포함하지 않습니다.
자막 글꼴: Galmuri11 (갈무리11). 동봉한 GALMURI-LICENSE.txt를 참고하세요.
메뉴 이미지 글자는 별도 제작한 그래픽입니다.
게임에 대한 권리는 각 권리자에게 있습니다.
